const style = document.createElement('style');
style.textContent = `
     :root{--fundo: #1a0526; --painel: #5b21b6; --botao: #7c3aed; --botao-escuro: #6d28d9; --texto: #ffffff}
     *{box-sizing: border-box; font-family: Inter,Segoe UI,Roboto,Arial,sans-serif}
     html,body{heigth: 100%; margin: 0; background: var(--fundo) ;display:flex;align-items:center;justify-content:center}
     .calc{width: 320px; background: var(--painel); border-radius:14px; padding: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.45); color: var(--texto); margin: 5rem}
     .screen{height: 72px; background: transparent; border-radius: 10px; padding: 10px; display: flex; flex-direction: column; justify-content: center; align-items: flex-end; gap: 4px}
     .history{font-size: 12px; opacity: 0.85; min-height: 14px; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap}
     .output{font-size: 28px; font-weight:600}
     .grid{display: grid; grid-template-columns: repeat(4,1fr); gap: 10px; margin-top:14px}
     button{height: 54px; border-radius: 10px; border: 0; background: var(--botao); color: var(--texto); font-size: 18px; cursor:pointer;box-shadow: inset 0 -3px 0 rgba(0,0,0,0.2)}
     button:active{transform:translateY(1px)}
      .op{background:transparent;border:1px solid rgba(255,255,255,0.08)}
      .accent{background:var(--botao-escuro);color:var(--texto);font-weight:700}
      .wide{grid-column:span 2}
     `;



document.head.appendChild(style);

const app = document.createElement('main');
app.className = 'calc';

const screen = document.createElement('div');
screen.className = 'screen';

const historicoEl = document.createElement('div');
historicoEl.className = 'history';
historicoEl.textContent = '';

const saidaEl = document.createElement('div');
saidaEl.className = 'output';
saidaEl.textContent = '0';

screen.appendChild(historicoEl);
screen.appendChild(saidaEl);

const grid = document.createElement('div');
grid.className = 'grid';

const botoes = [
    {t: 'C', cls: 'op'},  {t: '⌫' , cls: 'op'}, {t: '%', cls: 'op'}, {t: '÷', cls: 'accent op'},
    {t: '7'}, {t: '8'}, {t: '9'}, {t: '×', cls: 'accent op'},
    {t: '4'}, {t: '5'}, {t: '6'}, {t: '-', cls: 'accent op'},
    {t: '1'}, {t: '2'}, {t: '3'}, {t: '+', cls: 'accent op'},
    {t: '±', cls: 'op'}, {t: '0', cls: 'wide'}, {t: '.', cls: ''}, {t: '=', cls: 'accent'}
];

botoes.forEach(b=> {
    const btn = document.createElement('button');
    btn.textContent = b.t;
    if(b.cls) btn.className = b.cls;
    if(b.t === '0') btn.classList.add('zero');
    grid.appendChild(btn);
});

app.appendChild(screen);
app.appendChild(grid);
document.body.appendChild(app);

let atual = '0';
let anterior = null;
let operador = null;
let reiniciarProximo = false;

const toDisplay = (v) =>{
    saidaEl.textContent = String(v).slice(0,18);
};

function inputDigit (d){
    if(reiniciarProximo){
        atual = d === '.' ? '0.' : d; reiniciarProximo = false;
    }
    else if(atual === '0' && d !== '.') atual = d;
    else if (atual.includes('.') && d === '.') return;
    else atual = atual + d;
    toDisplay(atual);
}

function chooseOperator(op){
    if(op === '±'){
        atual = String(Number(atual) * -1);
        toDisplay(atual); return;
    }

    if(op === '%'){
        atual = String(Number(atual)/ 100);
        toDisplay(atual); return;
    }

    if(operador && !reiniciarProximo){
        compute();
    }

    anterior = atual;
    operador = op;
    reiniciarProximo = true;
    historicoEl.textContent = `${anterior} ${op}`;
}

function compute(){
    if(!operador || anterior === null) return;
    const a = Number(anterior);
    const b = Number(atual);
    let res = 0;
    switch(operador){
        case '+': res = a + b; break;
        case '-': res = a - b; break;
        case '×': res = a * b; break;
        case '÷': res = b === 0 ?'Error': a / b ; break;
    }

    atual = String(res);
    toDisplay(atual);
    historicoEl.textContent = `${anterior} ${operador} ${b} =`;
    operador = null;
    anterior = null;
    reiniciarProximo = true;
}

function clearAll(){
    atual = '0';
    anterior = null;
    operador = null;
    reiniciarProximo = false;
    historicoEl.textContent = '';
    toDisplay(atual);
}

function backspace (){
    if(atual.length > 1)
        atual = atual.slice(0, -1);
    else atual = '0';
    toDisplay(atual);
}

grid.addEventListener('click', (e) => {
    if (e.target.tagName !== 'BUTTON') return;
    const t = e.target.textContent;
    if(/^[0-9]$/.test(t)) inputDigit(t);
    else if(t === '.') inputDigit('.');
    else if(t === 'C') clearAll();
    else if(t === '⌫') backspace();
    else if (t === '=') compute();
    else if(['+','-','×','÷','%','±'].includes(t)) chooseOperator(t);

});

window.addEventListener('keydown', (e)=>{
    if((e.key >= '0' && e.key <= '9')){ inputDigit(e.key); e.preventDefault(); }
      else if(e.key === '.') inputDigit('.');
      else if(e.key === 'Enter' || e.key === '='){ compute(); e.preventDefault(); }
      else if(e.key === 'Backspace'){ backspace(); }
      else if(e.key === 'Escape'){ clearAll(); }
      else if(e.key === '+') chooseOperator('+');
      else if(e.key === '-') chooseOperator('-');
      else if(e.key === '*') chooseOperator('×');
      else if(e.key === '/') chooseOperator('÷');
      else if(e.key === '%') chooseOperator('%');
});

toDisplay(atual);



